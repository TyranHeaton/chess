package chess;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;

public class KingMoveCalculator implements PieceMoveCalculator{
    public Collection<ChessMove> calculatePossibleMoves(ChessBoard board, ChessPosition currentPosition) {
        Collection<ChessMove> possibleMoves = new ArrayList<>();
        ChessGame.TeamColor teamColor = board.getPiece(currentPosition).getTeamColor();
        int currentRow = currentPosition.getRow();
        int currentCol = currentPosition.getColumn();
        int[] rowOffsets = {1, 1, 1, 0, 0, -1, -1, -1};
        int[] colOffsets = {1, -1, 0, 1, -1, 1, -1, 0};
        for (int i = 0; i < 8; i++){
            int targetRow = currentRow + rowOffsets[i];
            int targetCol = currentCol + colOffsets[i];
            if (targetCol > 0 && targetRow > 0 && targetCol < 9 && targetRow < 9){
                ChessPosition targetPosition = new ChessPosition(targetRow, targetCol);
                ChessPiece pieceAtTarget = board.getPiece(targetPosition);
                if (pieceAtTarget == null || pieceAtTarget.getTeamColor() != teamColor){
                    possibleMoves.add(new ChessMove(currentPosition, targetPosition, null));
                }
            }
        }
        return possibleMoves;
    }
}
