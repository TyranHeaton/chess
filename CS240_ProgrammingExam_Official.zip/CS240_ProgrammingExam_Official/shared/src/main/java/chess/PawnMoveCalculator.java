package chess;
import java.util.Collection;
import java.util.ArrayList;

public class PawnMoveCalculator implements PieceMoveCalculator{
    public Collection<ChessMove> calculatePossibleMoves(ChessBoard board, ChessPosition currentPosition){
        Collection<ChessMove> possibleMoves = new ArrayList<>();
        ChessGame.TeamColor teamColor = board.getPiece(currentPosition).getTeamColor();
        int direction = 1;
        if (teamColor == ChessGame.TeamColor.BLACK){
            direction = -1;
        }
        int currentRow = currentPosition.getRow();
        int currentCol = currentPosition.getColumn();
        int targetRow = currentRow + direction;
        // Forward
        if (targetRow > 0 && currentCol > 0 && targetRow < 9 && currentCol < 9) {
            ChessPosition targetPosition = new ChessPosition(targetRow, currentCol);
            ChessPiece pieceAtTarget = board.getPiece(targetPosition);
            if (pieceAtTarget == null && (targetRow == 8 || targetRow == 1)){
                possibleMoves.add(new ChessMove(currentPosition, targetPosition, ChessPiece.PieceType.QUEEN));
                possibleMoves.add(new ChessMove(currentPosition, targetPosition, ChessPiece.PieceType.BISHOP));
                possibleMoves.add(new ChessMove(currentPosition, targetPosition, ChessPiece.PieceType.KNIGHT));
                possibleMoves.add(new ChessMove(currentPosition, targetPosition, ChessPiece.PieceType.ROOK));
            }
            else if (pieceAtTarget == null){
                possibleMoves.add(new ChessMove(currentPosition, targetPosition, null));
                if (currentRow == 2 || currentRow == 7){
                    int twoStepCheck = currentRow + (direction * 2);
                    ChessPosition twoStepCheckP = new ChessPosition(twoStepCheck, currentCol);
                    ChessPiece pieceAtTargetP = board.getPiece(twoStepCheckP);
                    if (pieceAtTargetP == null){
                        possibleMoves.add(new ChessMove(currentPosition, twoStepCheckP, null));
                    }
                }
            }

        }
        // Diagonal Piece Capture
        int[] colOffsets = {-1,1};
        for (int i = 0; i < 2; i++){
            int targetCol = currentCol + colOffsets[i];
            if (targetRow > 0 && targetCol > 0 && targetRow < 9 && targetCol < 9){
                ChessPosition targetPosition = new ChessPosition(targetRow, targetCol);
                ChessPiece pieceAtTarget = board.getPiece(targetPosition);
                if (pieceAtTarget != null && pieceAtTarget.getTeamColor() != teamColor && (targetRow == 1 || targetRow == 8)){
                    possibleMoves.add(new ChessMove(currentPosition, targetPosition, ChessPiece.PieceType.QUEEN));
                    possibleMoves.add(new ChessMove(currentPosition, targetPosition, ChessPiece.PieceType.BISHOP));
                    possibleMoves.add(new ChessMove(currentPosition, targetPosition, ChessPiece.PieceType.KNIGHT));
                    possibleMoves.add(new ChessMove(currentPosition, targetPosition, ChessPiece.PieceType.ROOK));
                }
                else if (pieceAtTarget != null && pieceAtTarget.getTeamColor() != teamColor){
                    possibleMoves.add(new ChessMove(currentPosition, targetPosition, null));
                }
            }
        }
        return possibleMoves;
    }
}
