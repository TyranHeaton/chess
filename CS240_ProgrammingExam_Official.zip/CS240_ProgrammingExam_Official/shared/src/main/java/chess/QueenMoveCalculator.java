package chess;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;

public class QueenMoveCalculator implements PieceMoveCalculator{
    public Collection<ChessMove> calculatePossibleMoves(ChessBoard board, ChessPosition currentPosition) {
        Collection<ChessMove> possibleMoves = new ArrayList<>();
        ChessGame.TeamColor teamColor = board.getPiece(currentPosition).getTeamColor();
        int[] rowOffsets = {1, 1, 1, 0, 0, -1, -1, -1};
        int[] colOffsets = {-1, 0, 1, 1, -1, -1, 1, 0};
        for (int i = 0; i < 8; i++){
            int currentRow = currentPosition.getRow();
            int currentCol = currentPosition.getColumn();
            while(true){
                currentRow += rowOffsets[i];
                currentCol += colOffsets[i];
                if (currentRow < 1 || currentCol < 1 || currentRow > 8 || currentCol > 8){
                    break;
                }
                ChessPosition targetPosition = new ChessPosition(currentRow, currentCol);
                ChessPiece pieceAtTarget = board.getPiece(targetPosition);
                if (pieceAtTarget == null){
                    possibleMoves.add(new ChessMove(currentPosition, targetPosition, null));
                }
                if (pieceAtTarget != null && pieceAtTarget.getTeamColor() != teamColor){
                    possibleMoves.add(new ChessMove(currentPosition, targetPosition, null));
                    break;
                }
                if (pieceAtTarget != null && pieceAtTarget.getTeamColor() == teamColor){
                    break;
                }
            }
        }
        return possibleMoves;
    }
}
