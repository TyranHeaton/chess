package chess;
import java.util.Collection;

public interface PieceMoveCalculator {
    Collection<ChessMove> calculatePossibleMoves(ChessBoard board, ChessPosition currentPosition);
}
